package day07;

public class PersonTest {

	public static void main(String[] args) {
		//person 객체 생성하기
		Person hong = new Person();
//		hong.name = "홍길동";
//		hong.age = 20;
//		hong.abc = 'A';
		hong.밥먹기();
		hong.운동하기("헬스");
//		hong.addr = "대전동구 용운동";
		System.out.println(hong.getName());
	}

}
