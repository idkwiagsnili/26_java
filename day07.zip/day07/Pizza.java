package day07;

class Circle {
	int radius;
	String name;
	
	public Circle() {
		this(0,"");
	}
	
	public Circle(int radius){
		this(radius, "불고기피자");
	}
	
	public Circle(int radius, String name) {
		this.radius = radius;
		this.name = name;
	}
	
	public double getArea() {
        return 3.14 * radius * radius;
    }
}

public class Pizza {

	public static void main(String[] args) {
		//1. 레퍼런스 변수 pizza선언
		Circle pizza, pizza2;
		//2. Circle 객체 생성
		pizza = new Circle(10,"불고기피자");
		pizza2 = new Circle(10, "치즈피자");
		//3. 피자의 반지름을 10으로설정
		//pizza.radius = 10;
		//4. 피자의 이름을 불고기피자로 설정
		//pizza.name = "불고기피자";
		//5. 피자의 면적 메소드 호출하여 알아내기
		//ystem.out.println(pizza.name + "의 면적은 " + pizza.getArea());
		System.out.println(pizza2.name + "의 면적은 " + pizza2.getArea());
		
		//레퍼런스 변수 donut선언
		Circle donut;
		donut = new Circle();
		donut.radius = 5;
		donut.name = "자바도넛";
		System.out.println(donut.name + "의 면적은 " + donut.getArea());
	}

}
