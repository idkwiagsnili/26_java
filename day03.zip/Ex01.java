package day03;

import java.util.Scanner;
public class Ex01 {

	public static void main(String[] args) {
		int age;
		String name = new String();
		age = 21;
		name = "장현성";
		
		Scanner scan = new Scanner(System.in);
		System.out.print("나이를 입력 하세요 : ");
		age = scan.nextInt();
		System.out.print("이름을 입력하세요 : ");
		name = scan.next();
		double height;
		System.out.print("키를 입력하세요 : ");
		height = scan.nextDouble();
		String city = new String();
		System.out.print("도시를 입력하세요 : ");
		city = scan.next();
		System.out.print("싱글 여부를 입력하세요 : ");
		boolean single = scan.nextBoolean();
		
		
		System.out.println("나이 : "+age);
		System.out.println("이름 : "+name);
		System.out.println("키 : "+height);
		System.out.println("도시 : "+city);
		System.out.println("독신 여부는 "+single+"입니다.");
		scan.close();
	}

}
