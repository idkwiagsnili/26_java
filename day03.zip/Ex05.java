package day03;
import java.util.Scanner;
public class Ex05 {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.print("아이디를 입력하세요 : ");
		String id = scan.next();
		System.out.print("비밀번호를 입력하세요 : ");
		int pwd = scan.nextInt();
		
		if(id.equals("hi") && pwd == 21) {
			System.out.println("로그인");
		}
		else {
			System.out.println("다시");
		}
	}

}
