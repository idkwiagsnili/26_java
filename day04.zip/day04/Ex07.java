package day04;
import java.util.Scanner;
public class Ex07 {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		int total = 0;
		while(true){
			int num = scan.nextInt();
			if(num < 0) {
				break;
			}
			total += num;
		}
		System.out.println("양수의 합은 " + total + "입니다.");
		scan.close();
	}

}
