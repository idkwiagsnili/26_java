package day04;

public class Ex05 {

	public static void main(String[] args) {
//		int sum = 0;
//		int i=1;
//		while(i <= 10) {
//			sum += i;
//			i++;
//		}
//		System.out.println(sum);
		int i = 1;
		int sum = 0;
		do {
			sum += i;
			i++;
		}while(i<=100);
		System.out.println(sum);
	}

}
