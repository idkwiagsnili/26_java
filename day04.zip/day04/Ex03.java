package day04;
import java.util.Scanner;
public class Ex03 {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		int balance = 10000;
		System.out.print("나이를 입력하시오 : ");
		int age = scan.nextInt();
		if(age >= 19) {
			balance -= 1200;
		}
		else if(age >= 13) {
			balance -= 720;
		}
		else {
			balance -= 450;
		}
		if(balance == 10000) {
			System.out.println("돈내놔");
		}
		else {
			System.out.println("남은 잔액 : " + balance);
		}
	}

}
