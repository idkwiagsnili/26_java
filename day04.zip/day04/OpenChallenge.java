package day04;
import java.util.Scanner;
public class OpenChallenge {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.print("철수 가위바위보 입력 : ");
		String user1 = scan.next();
		System.out.print("영희 가위바위보 입력 : ");
		String user2 = scan.next();
		System.out.println("철수>>>"+user1);
		System.out.println("영희>>>"+user2);
		if(user1.equals(user2)) {
			System.out.println("비겼어");
		}
		else if(user1.equals("가위")) {
			if(user2.equals("바위")) {
				System.out.println("영희 승");
			}
			else {
				System.out.println("철수 승");
			}
		}
		else if(user1.equals("바위")) {
			if(user2.equals("보")) {
				System.out.println("영희 승");
			}
			else {
				System.out.println("철수 승");
			}
		}
		else if(user1.equals("보")) {
			if(user2.equals("가위")) {
				System.out.println("영희 승");
			}
			else {
				System.out.println("철수 승");
			}
		}
	}

}
