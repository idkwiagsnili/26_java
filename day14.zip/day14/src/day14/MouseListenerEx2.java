package day14;

import java.awt.Container;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class MouseListenerEx2 extends JFrame {

    JLabel lb;

    public MouseListenerEx2() {

        Container con = getContentPane();
        con.setLayout(null);

        lb = new JLabel("hello");
        lb.setLocation(30, 30);
        lb.setSize(50, 20);
        con.add(lb);

        // 이벤트 리스너 등록하기
        con.addMouseMotionListener(new MyMouseListener2());

        setSize(400, 400);
        setVisible(true);
        setTitle(lb.getText());
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

    public static void main(String[] args) {
        new MouseListenerEx2();
    }

    // 내부 클래스(Inner Class)로 마우스 리스너 객체 구현
    class MyMouseListener2 extends MouseMotionAdapter {

        @Override
        public void mouseDragged(MouseEvent e) {
            lb.setText(
                "MouseDragged (" + e.getX() + "," + e.getY() + ")"
            );
        }

        @Override
        public void mouseMoved(MouseEvent e) {
            super.mouseMoved(e);
        }
    }
}