package day14;

import java.awt.FlowLayout;
import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

public class MyJFrame extends JFrame {

    public MyJFrame() {
        setTitle("나만의 프레임");

        Container con = getContentPane();
        con.setLayout(new FlowLayout());

        JButton btn = new JButton("소개");
        con.add(btn);

        btn.addActionListener(new MyActionListener());

        con.add(new JTextField(20));

        setSize(300, 200);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }

    public static void main(String[] args) {
        new MyJFrame();
    }
}

// 독립적인 이벤트 리스너 클래스
class MyActionListener implements ActionListener {

    @Override
    public void actionPerformed(ActionEvent e) {
        JOptionPane.showMessageDialog(
                null,
                "소개 버튼을 클릭했습니다."
        );
    }
}