package day02;

public class Hello0310 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("자바 코드를 봤을때");
		System.out.print("이 코드가 어떻게 동작하는지\n");
		System.out.println("알 수 있을 정도(남이 만든 코드 확인)");
		
	}

}
