package day02;

public class DataTypeTest {

	public static void main(String[] args) {
		//1. 기본형
		boolean isTrue;
		int age;
		double height, weight;
		
		//2. 변수 초기화
		isTrue = false;
		age = 21;
		height = 182.3;
		weight = 64.4;
		
		//2. 레퍼런스형 - 3개 (배열, 클래스, 인터페이스)
		String name = "장현성";
		//name = "장현성";
		String s = new String("홍길동");
		String addr = "안산시 상록구 건건5길 10";
		DataTypeTest dtt = new DataTypeTest();
		
		//3. 변수 값 출력하기
		System.out.println(isTrue);
		System.out.println("나이: "+age);
		System.out.println("키: "+height);
		System.out.println("몸무게: "+weight);
		System.out.println("이름: "+name);
		System.out.println("주소: "+addr);
		
	}

}
