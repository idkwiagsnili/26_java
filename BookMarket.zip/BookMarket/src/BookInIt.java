import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

public class BookInIt {
    private BookInIt() {
    }

    public static List<Book> initBooks() {
        List<Book> books = readBookFile();
        if (books.isEmpty()) {
            books.add(new Book("ISBN1234", "쉽게 배우는 JSP 웹 프로그래밍", 27000,
                    "송미영", "단계별로 쇼핑몰을 구현하며 배우는 JSP 웹 프로그래밍", "IT전문서", "2018/10/08"));
            books.add(new Book("ISBN1235", "안드로이드 프로그래밍", 33000,
                    "우재남", "실습 단계별 명쾌한 멘토링!", "IT전문서", "2022/01/22"));
            books.add(new Book("ISBN1236", "스크래치", 22000,
                    "고광일", "컴퓨팅 사고력을 키우는 블록 코딩", "컴퓨터입문", "2019/06/10"));
        }
        return books;
    }

    private static List<Book> readBookFile() {
        List<Book> books = new ArrayList<>();
        InputStream stream = BookInIt.class.getResourceAsStream("book.txt");
        if (stream == null) {
            return books;
        }

        try (BufferedReader reader = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.isBlank() || line.startsWith("#")) {
                    continue;
                }

                String[] data = line.split("\\|", -1);
                if (data.length < 7) {
                    continue;
                }
                books.add(new Book(data[0], data[1], Integer.parseInt(data[2]),
                        data[3], data[4], data[5], data[6]));
            }
        } catch (IOException | NumberFormatException e) {
            books.clear();
        }
        return books;
    }
}
