
public class CartItem {
    private Book itemBook;
    private String bookID;
    private int quantity;
    private int totalPrice;

    public CartItem(Book book) {
        this.itemBook = book;
        this.bookID = book.getBookID();
        this.quantity = 1;
        updateTotalPrice();
    }

    public Book getItemBook() {
        return itemBook;
    }

    public void setItemBook(Book itemBook) {
        this.itemBook = itemBook;
        this.bookID = itemBook.getBookID();
        updateTotalPrice();
    }

    public String getBookID() {
        return bookID;
    }

    public void setBookID(String bookID) {
        this.bookID = bookID;
        updateTotalPrice();
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
        updateTotalPrice();
    }

    public int getTotalPrice() {
        return totalPrice;
    }

    public void setTotalPrice(int totalPrice) {
        this.totalPrice = totalPrice;
    }

    public void updateTotalPrice() {
        totalPrice = itemBook.getUnitPrice() * quantity;
    }
}
