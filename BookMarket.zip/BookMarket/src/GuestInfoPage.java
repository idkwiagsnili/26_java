import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;

import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.JPanel;


public class GuestInfoPage extends JPanel {
    public GuestInfoPage(User user) {
        super(new BorderLayout(0, 16));
        setBackground(Color.WHITE);
        setBorder(BorderFactory.createEmptyBorder(28, 28, 28, 28));

        JLabel title = new JLabel("현재 고객 정보");
        title.setFont(title.getFont().deriveFont(Font.BOLD, 22f));

        String address = user.getAddress() == null ? "" : user.getAddress();
        JLabel info = new JLabel("<html>이름 : " + user.getName()
                + "<br>연락처 : " + user.getPhone()
                + "<br>주소 : " + address + "</html>");
        info.setFont(info.getFont().deriveFont(16f));

        add(title, BorderLayout.NORTH);
        add(info, BorderLayout.CENTER);
    }
}
