
public class Cart implements CartInterface {
    private static final int NUM_BOOK = 100;

    public CartItem[] mCartItem = new CartItem[NUM_BOOK];
    public int mCartCount = 0;

    @Override
    public void printBookList(Book[] books) {
        for (Book book : books) {
            System.out.print(book.getBookID() + " | ");
            System.out.print(book.getName() + " | ");
            System.out.print(book.getUnitPrice() + " | ");
            System.out.print(book.getAuthor() + " | ");
            System.out.print(book.getDescription() + " | ");
            System.out.print(book.getCategory() + " | ");
            System.out.println(book.getReleaseDate());
        }
    }

    @Override
    public boolean isCartInBook(String bookId) {
        for (int i = 0; i < mCartCount; i++) {
            if (bookId.equals(mCartItem[i].getBookID())) {
                mCartItem[i].setQuantity(mCartItem[i].getQuantity() + 1);
                return true;
            }
        }
        return false;
    }

    @Override
    public void insertBook(Book book) {
        if (mCartCount >= mCartItem.length) {
            return;
        }
        mCartItem[mCartCount++] = new CartItem(book);
    }

    @Override
    public void removeCart(int numId) {
        if (numId < 0 || numId >= mCartCount) {
            return;
        }

        for (int i = numId; i < mCartCount - 1; i++) {
            mCartItem[i] = mCartItem[i + 1];
        }
        mCartItem[--mCartCount] = null;
    }

    @Override
    public void deleteBook() {
        mCartItem = new CartItem[NUM_BOOK];
        mCartCount = 0;
    }

    public void addBook(Book book) {
        if (!isCartInBook(book.getBookID())) {
            insertBook(book);
        }
    }

    public int findCartItemIndex(String bookId) {
        for (int i = 0; i < mCartCount; i++) {
            if (bookId.equals(mCartItem[i].getBookID())) {
                return i;
            }
        }
        return -1;
    }

    public int getTotalPrice() {
        int sum = 0;
        for (int i = 0; i < mCartCount; i++) {
            sum += mCartItem[i].getTotalPrice();
        }
        return sum;
    }

    public CartItem[] getCartItem() {
        return mCartItem;
    }

    public void setCartItem(CartItem[] cartItem) {
        this.mCartItem = cartItem;
    }

    public int getCartCount() {
        return mCartCount;
    }

    public void setCartCount(int cartCount) {
        this.mCartCount = cartCount;
    }
}
