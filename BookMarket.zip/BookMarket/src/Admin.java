public class Admin extends Person {
    private String id = "Admin";
    private String password = "Admin1234";

    public Admin(String name, int phone) {
        super(name, phone);
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}
