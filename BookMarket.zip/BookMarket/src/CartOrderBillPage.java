import java.awt.BorderLayout;
import java.awt.Color;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.swing.BorderFactory;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;


public class CartOrderBillPage extends JPanel {
    public CartOrderBillPage(Cart cart, String name, String phone, String address) {
        super(new BorderLayout());
        setBackground(Color.WHITE);
        setBorder(BorderFactory.createEmptyBorder(16, 16, 16, 16));

        JTextArea billArea = new JTextArea(makeBill(cart, name, phone, address));
        billArea.setEditable(false);
        billArea.setFont(billArea.getFont().deriveFont(14f));
        add(new JScrollPane(billArea), BorderLayout.CENTER);
    }

    private String makeBill(Cart cart, String name, String phone, String address) {
        String date = new SimpleDateFormat("MM/dd/yyyy").format(new Date());
        StringBuilder builder = new StringBuilder();

        builder.append("----------------배송받을 고객 정보----------------\n");
        builder.append("고객명 : ").append(name).append("\t연락처 : ").append(phone).append("\n");
        builder.append("배송지 : ").append(address).append("\t발송일 : ").append(date).append("\n\n");
        builder.append("----------------장바구니 상품 목록----------------\n");
        builder.append("도서ID\t수량\t합계\n");

        for (int i = 0; i < cart.getCartCount(); i++) {
            CartItem item = cart.getCartItem()[i];
            builder.append(item.getBookID()).append("\t")
                    .append(item.getQuantity()).append("\t")
                    .append(item.getTotalPrice()).append("원\n");
        }

        builder.append("\n주문 총금액 : ").append(cart.getTotalPrice()).append("원\n");
        builder.append("---------------------------------------------\n");
        return builder.toString();
    }
}
