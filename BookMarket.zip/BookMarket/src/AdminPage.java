import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.table.DefaultTableModel;


public class AdminPage extends JPanel {
    private final List<Book> books;
    private final DefaultTableModel model;
    private final JTable table;
    private final JTextField idField = new JTextField(10);
    private final JTextField nameField = new JTextField(18);
    private final JTextField priceField = new JTextField(8);
    private final JTextField authorField = new JTextField(10);
    private final JTextField descriptionField = new JTextField(20);
    private final JTextField categoryField = new JTextField(10);
    private final JTextField releaseField = new JTextField(10);

    public AdminPage(List<Book> books) {
        super(new BorderLayout(12, 12));
        this.books = books;
        setBackground(Color.WHITE);
        setBorder(BorderFactory.createEmptyBorder(16, 16, 16, 16));

        model = new DefaultTableModel(new Object[] { "도서ID", "도서명", "가격", "저자", "분야", "출간일" }, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        table = new JTable(model);
        table.setRowHeight(28);
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        add(new JScrollPane(table), BorderLayout.CENTER);
        add(createEditor(), BorderLayout.SOUTH);
        refresh();
    }

    private JPanel createEditor() {
        JPanel wrapper = new JPanel(new BorderLayout(8, 8));
        wrapper.setOpaque(false);

        JPanel form = new JPanel(new GridBagLayout());
        form.setOpaque(false);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(4, 4, 4, 4);
        gbc.anchor = GridBagConstraints.WEST;

        addField(form, gbc, 0, "도서ID", idField);
        addField(form, gbc, 1, "도서명", nameField);
        addField(form, gbc, 2, "가격", priceField);
        addField(form, gbc, 3, "저자", authorField);
        addField(form, gbc, 4, "설명", descriptionField);
        addField(form, gbc, 5, "분야", categoryField);
        addField(form, gbc, 6, "출간일", releaseField);

        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        buttons.setOpaque(false);

        JButton addButton = new JButton("추가");
        addButton.addActionListener(event -> addBook());

        JButton removeButton = new JButton("삭제");
        removeButton.addActionListener(event -> removeSelected());

        JButton cancelButton = new JButton("취소");
        cancelButton.addActionListener(event -> clearFields());

        buttons.add(addButton);
        buttons.add(removeButton);
        buttons.add(cancelButton);

        wrapper.add(form, BorderLayout.CENTER);
        wrapper.add(buttons, BorderLayout.SOUTH);
        return wrapper;
    }

    private void addField(JPanel form, GridBagConstraints gbc, int row, String label, JTextField field) {
        gbc.gridx = 0;
        gbc.gridy = row;
        form.add(new JLabel(label), gbc);

        gbc.gridx = 1;
        form.add(field, gbc);
    }

    private void refresh() {
        model.setRowCount(0);
        for (Book book : books) {
            model.addRow(new Object[] {
                    book.getBookID(),
                    book.getName(),
                    book.getUnitPrice(),
                    book.getAuthor(),
                    book.getCategory(),
                    book.getReleaseDate()
            });
        }
    }

    private void addBook() {
        String id = idField.getText().trim();
        String name = nameField.getText().trim();
        String priceText = priceField.getText().trim();
        String author = authorField.getText().trim();
        String description = descriptionField.getText().trim();
        String category = categoryField.getText().trim();
        String release = releaseField.getText().trim();

        if (id.isEmpty() || name.isEmpty() || priceText.isEmpty()) {
            JOptionPane.showMessageDialog(this, "도서ID, 도서명, 가격을 입력하세요.");
            return;
        }

        for (Book book : books) {
            if (id.equals(book.getBookID())) {
                JOptionPane.showMessageDialog(this, "이미 등록된 도서ID입니다.");
                return;
            }
        }

        int price;
        try {
            price = Integer.parseInt(priceText);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "가격은 숫자로 입력하세요.");
            return;
        }

        books.add(new Book(id, name, price, author, description, category, release));
        clearFields();
        refresh();
    }

    private void removeSelected() {
        int row = table.getSelectedRow();
        if (row < 0) {
            JOptionPane.showMessageDialog(this, "도서를 선택하세요.");
            return;
        }

        int result = JOptionPane.showConfirmDialog(this, "선택한 도서를 삭제하겠습니까?", "도서 삭제",
                JOptionPane.YES_NO_OPTION);
        if (result == JOptionPane.YES_OPTION) {
            books.remove(table.convertRowIndexToModel(row));
            refresh();
        }
    }

    private void clearFields() {
        idField.setText("");
        nameField.setText("");
        priceField.setText("");
        authorField.setText("");
        descriptionField.setText("");
        categoryField.setText("");
        releaseField.setText("");
    }
}
