public class UserInIt {
    private UserInIt() {
    }

    public static User initUser(String name, int phone) {
        return new User(name, phone);
    }
}
