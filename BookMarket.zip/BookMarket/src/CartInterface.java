
public interface CartInterface {
    void printBookList(Book[] books);

    boolean isCartInBook(String id);

    void insertBook(Book book);

    void removeCart(int numId);

    void deleteBook();
}
