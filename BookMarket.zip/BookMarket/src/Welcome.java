import java.util.List;

import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;


public class Welcome {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try {
                UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
            } catch (Exception e) {
                UIManager.getLookAndFeel();
            }

            User user = inputUser();
            if (user == null) {
                return;
            }

            List<Book> books = BookInIt.initBooks();
            Cart cart = new Cart();
            MainWindow window = new MainWindow(user, books, cart);
            window.setVisible(true);
        });
    }

    private static User inputUser() {
        String name = JOptionPane.showInputDialog(null, "당신의 이름을 입력하세요", "고객 정보 입력",
                JOptionPane.QUESTION_MESSAGE);
        if (name == null || name.trim().isEmpty()) {
            return null;
        }

        while (true) {
            String phoneText = JOptionPane.showInputDialog(null, "연락처를 입력하세요", "고객 정보 입력",
                    JOptionPane.QUESTION_MESSAGE);
            if (phoneText == null) {
                return null;
            }

            String digits = phoneText.replaceAll("[^0-9]", "");
            try {
                return UserInIt.initUser(name.trim(), Integer.parseInt(digits));
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "연락처는 숫자로 입력하세요.");
            }
        }
    }
}
