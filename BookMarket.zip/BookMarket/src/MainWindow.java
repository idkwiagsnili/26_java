import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JLabel;


public class MainWindow extends JFrame {
    private final User user;
    private final List<Book> books;
    private final Cart cart;
    private final JPanel pagePanel = new JPanel(new BorderLayout());

    public MainWindow(User user, List<Book> books, Cart cart) {
        this.user = user;
        this.books = books;
        this.cart = cart;

        setTitle("온라인 서점");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setMinimumSize(new Dimension(1040, 680));
        setLocationRelativeTo(null);
        setJMenuBar(createMenuBar());

        JPanel root = new JPanel(new BorderLayout(14, 14));
        root.setBorder(BorderFactory.createEmptyBorder(18, 18, 18, 18));
        root.setBackground(Color.WHITE);

        root.add(createHeader(), BorderLayout.NORTH);
        root.add(createButtonPanel(), BorderLayout.WEST);

        pagePanel.setBackground(Color.WHITE);
        pagePanel.setBorder(BorderFactory.createLineBorder(new Color(215, 220, 228)));
        root.add(pagePanel, BorderLayout.CENTER);

        setContentPane(root);
        showPage(new CartAddItemPage(books, cart));
        pack();
    }

    private JLabel createHeader() {
        JLabel title = new JLabel("Welcome to Book Market!");
        title.setFont(title.getFont().deriveFont(Font.BOLD, 26f));
        return title;
    }

    private JPanel createButtonPanel() {
        JPanel panel = new JPanel(new GridLayout(9, 1, 0, 8));
        panel.setOpaque(false);
        panel.setPreferredSize(new Dimension(210, 0));

        panel.add(menuButton("1. 고객 정보 확인하기", () -> showPage(new GuestInfoPage(user))));
        panel.add(menuButton("2. 장바구니 상품 목록 보기", () -> showPage(new CartItemListPage(cart))));
        panel.add(menuButton("3. 장바구니 비우기", this::clearCart));
        panel.add(menuButton("4. 바구니에 항목 추가하기", () -> showPage(new CartAddItemPage(books, cart))));
        panel.add(menuButton("5. 장바구니의 항목 수량 줄이기", () -> showPage(new CartItemListPage(cart))));
        panel.add(menuButton("6. 장바구니의 항목 삭제하기", () -> showPage(new CartItemListPage(cart))));
        panel.add(menuButton("7. 주문하기", this::showShippingPage));
        panel.add(menuButton("8. 종료", this::dispose));
        panel.add(menuButton("9. 관리자", this::showAdminPage));

        return panel;
    }

    private JButton menuButton(String text, Runnable action) {
        JButton button = new JButton(text);
        button.setFocusPainted(false);
        button.addActionListener(event -> action.run());
        return button;
    }

    private JMenuBar createMenuBar() {
        JMenuBar menuBar = new JMenuBar();
        JMenu menu = new JMenu("메뉴");

        JMenuItem guest = new JMenuItem("고객 정보");
        guest.addActionListener(event -> showPage(new GuestInfoPage(user)));

        JMenuItem booksItem = new JMenuItem("상품 목록");
        booksItem.addActionListener(event -> showPage(new CartAddItemPage(books, cart)));

        JMenuItem exit = new JMenuItem("종료");
        exit.addActionListener(event -> dispose());

        menu.add(guest);
        menu.add(booksItem);
        menu.addSeparator();
        menu.add(exit);
        menuBar.add(menu);
        return menuBar;
    }

    private void showPage(JPanel panel) {
        pagePanel.removeAll();
        pagePanel.add(panel, BorderLayout.CENTER);
        pagePanel.revalidate();
        pagePanel.repaint();
    }

    private void clearCart() {
        if (cart.getCartCount() == 0) {
            JOptionPane.showMessageDialog(this, "장바구니에 항목이 없습니다.");
            return;
        }

        int result = JOptionPane.showConfirmDialog(this, "장바구니를 비우겠습니까?", "장바구니 비우기",
                JOptionPane.YES_NO_OPTION);
        if (result == JOptionPane.YES_OPTION) {
            cart.deleteBook();
            showPage(new CartItemListPage(cart));
        }
    }

    private void showShippingPage() {
        if (cart.getCartCount() == 0) {
            JOptionPane.showMessageDialog(this, "장바구니에 항목이 없습니다.");
            return;
        }
        showPage(new CartShippingPage(user, cart, this::showPage));
    }

    private void showAdminPage() {
        AdminLoginDialog dialog = new AdminLoginDialog(this);
        dialog.setVisible(true);
        if (dialog.isAuthenticated()) {
            showPage(new AdminPage(books));
        }
    }
}
