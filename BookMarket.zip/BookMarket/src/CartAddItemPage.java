import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableModel;


public class CartAddItemPage extends JPanel {
    private final List<Book> books;
    private final Cart cart;
    private final JTable table;
    private final JLabel detailLabel = new JLabel("", SwingConstants.CENTER);

    public CartAddItemPage(List<Book> books, Cart cart) {
        super(new BorderLayout(14, 14));
        this.books = books;
        this.cart = cart;
        setBackground(Color.WHITE);
        setBorder(BorderFactory.createEmptyBorder(16, 16, 16, 16));

        table = new JTable(createTableModel());
        table.setRowHeight(28);
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        table.getSelectionModel().addListSelectionListener(event -> updateDetail());

        add(new JScrollPane(table), BorderLayout.CENTER);
        add(createSidePanel(), BorderLayout.EAST);

        if (!books.isEmpty()) {
            table.setRowSelectionInterval(0, 0);
        }
    }

    private DefaultTableModel createTableModel() {
        DefaultTableModel model = new DefaultTableModel(
                new Object[] { "도서ID", "도서명", "가격", "저자", "분야", "출간일" }, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        for (Book book : books) {
            model.addRow(new Object[] {
                    book.getBookID(),
                    book.getName(),
                    book.getUnitPrice(),
                    book.getAuthor(),
                    book.getCategory(),
                    book.getReleaseDate()
            });
        }
        return model;
    }

    private JPanel createSidePanel() {
        JPanel panel = new JPanel(new BorderLayout(0, 12));
        panel.setOpaque(false);
        panel.setPreferredSize(new Dimension(240, 0));

        detailLabel.setOpaque(true);
        detailLabel.setBackground(new Color(240, 244, 248));
        detailLabel.setBorder(BorderFactory.createEmptyBorder(18, 18, 18, 18));

        JButton addButton = new JButton("장바구니에 담기");
        addButton.addActionListener(event -> addSelectedBook());

        panel.add(detailLabel, BorderLayout.CENTER);
        panel.add(addButton, BorderLayout.SOUTH);
        return panel;
    }

    private void updateDetail() {
        int row = table.getSelectedRow();
        if (row < 0) {
            detailLabel.setText("");
            return;
        }

        Book book = books.get(table.convertRowIndexToModel(row));
        detailLabel.setText("<html><h2>" + book.getName() + "</h2>"
                + "<p>" + book.getDescription() + "</p>"
                + "<p>저자 : " + book.getAuthor() + "</p>"
                + "<p>가격 : " + book.getUnitPrice() + "원</p></html>");
    }

    private void addSelectedBook() {
        int row = table.getSelectedRow();
        if (row < 0) {
            JOptionPane.showMessageDialog(this, "도서를 선택하세요.");
            return;
        }

        Book book = books.get(table.convertRowIndexToModel(row));
        cart.addBook(book);
        JOptionPane.showMessageDialog(this, book.getBookID() + " 도서가 장바구니에 추가되었습니다.");
    }
}
