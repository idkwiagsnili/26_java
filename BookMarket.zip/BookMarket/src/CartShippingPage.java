import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.util.function.Consumer;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;


public class CartShippingPage extends JPanel {
    private final User user;
    private final Cart cart;
    private final Consumer<JPanel> pageChanger;
    private final JTextField nameField = new JTextField(18);
    private final JTextField phoneField = new JTextField(18);
    private final JTextField addressField = new JTextField(30);
    private final JCheckBox sameCustomer = new JCheckBox("고객 정보와 동일");

    public CartShippingPage(User user, Cart cart, Consumer<JPanel> pageChanger) {
        super(new BorderLayout(12, 12));
        this.user = user;
        this.cart = cart;
        this.pageChanger = pageChanger;
        setBackground(Color.WHITE);
        setBorder(BorderFactory.createEmptyBorder(22, 22, 22, 22));

        sameCustomer.setOpaque(false);
        sameCustomer.addActionListener(event -> syncCustomer());

        add(createForm(), BorderLayout.CENTER);
        add(createButtonPanel(), BorderLayout.SOUTH);

        sameCustomer.setSelected(true);
        syncCustomer();
    }

    private JPanel createForm() {
        JPanel form = new JPanel(new GridBagLayout());
        form.setOpaque(false);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 8, 8, 8);
        gbc.anchor = GridBagConstraints.WEST;

        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        form.add(sameCustomer, gbc);

        gbc.gridwidth = 1;
        gbc.gridx = 0;
        gbc.gridy = 1;
        form.add(new JLabel("수령인"), gbc);
        gbc.gridx = 1;
        form.add(nameField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        form.add(new JLabel("연락처"), gbc);
        gbc.gridx = 1;
        form.add(phoneField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 3;
        form.add(new JLabel("배송지"), gbc);
        gbc.gridx = 1;
        form.add(addressField, gbc);

        return form;
    }

    private JPanel createButtonPanel() {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        panel.setOpaque(false);

        JButton orderButton = new JButton("주문 완료");
        orderButton.addActionListener(event -> order());
        panel.add(orderButton);

        return panel;
    }

    private void syncCustomer() {
        boolean same = sameCustomer.isSelected();
        if (same) {
            nameField.setText(user.getName());
            phoneField.setText(String.valueOf(user.getPhone()));
        }
        nameField.setEditable(!same);
        phoneField.setEditable(!same);
    }

    private void order() {
        String name = nameField.getText().trim();
        String phone = phoneField.getText().trim();
        String address = addressField.getText().trim();

        if (name.isEmpty() || phone.isEmpty() || address.isEmpty()) {
            JOptionPane.showMessageDialog(this, "배송 정보를 입력하세요.");
            return;
        }

        user.setAddress(address);
        pageChanger.accept(new CartOrderBillPage(cart, name, phone, address));
    }
}
