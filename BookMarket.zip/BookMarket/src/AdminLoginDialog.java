import java.awt.BorderLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.Window;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;


public class AdminLoginDialog extends JDialog {
    private final JTextField idField = new JTextField(14);
    private final JPasswordField passwordField = new JPasswordField(14);
    private boolean authenticated;

    public AdminLoginDialog(Window owner) {
        super(owner, "관리자 로그인", ModalityType.APPLICATION_MODAL);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);

        JPanel root = new JPanel(new BorderLayout(8, 8));
        root.setBorder(BorderFactory.createEmptyBorder(16, 16, 16, 16));
        root.add(createForm(), BorderLayout.CENTER);
        root.add(createButtonPanel(), BorderLayout.SOUTH);

        setContentPane(root);
        pack();
        setLocationRelativeTo(owner);
    }

    public boolean isAuthenticated() {
        return authenticated;
    }

    private JPanel createForm() {
        JPanel form = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(6, 6, 6, 6);
        gbc.anchor = GridBagConstraints.WEST;

        gbc.gridx = 0;
        gbc.gridy = 0;
        form.add(new JLabel("아이디"), gbc);
        gbc.gridx = 1;
        form.add(idField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        form.add(new JLabel("비밀번호"), gbc);
        gbc.gridx = 1;
        form.add(passwordField, gbc);

        return form;
    }

    private JPanel createButtonPanel() {
        JPanel panel = new JPanel();

        JButton loginButton = new JButton("로그인");
        loginButton.addActionListener(event -> login());

        JButton cancelButton = new JButton("취소");
        cancelButton.addActionListener(event -> dispose());

        panel.add(loginButton);
        panel.add(cancelButton);
        return panel;
    }

    private void login() {
        Admin admin = new Admin("관리자", 0);
        String id = idField.getText().trim();
        String password = new String(passwordField.getPassword());

        if (id.equals(admin.getId()) && password.equals(admin.getPassword())) {
            authenticated = true;
            dispose();
        } else {
            JOptionPane.showMessageDialog(this, "관리자 정보가 일치하지 않습니다.");
        }
    }
}
