import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.table.DefaultTableModel;


public class CartItemListPage extends JPanel {
    private final Cart cart;
    private final DefaultTableModel model;
    private final JTable table;

    public CartItemListPage(Cart cart) {
        super(new BorderLayout(12, 12));
        this.cart = cart;
        setBackground(Color.WHITE);
        setBorder(BorderFactory.createEmptyBorder(16, 16, 16, 16));

        model = new DefaultTableModel(new Object[] { "도서ID", "도서명", "수량", "가격", "합계" }, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        table = new JTable(model);
        table.setRowHeight(28);
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        add(new JScrollPane(table), BorderLayout.CENTER);
        add(createButtonPanel(), BorderLayout.SOUTH);
        refresh();
    }

    private JPanel createButtonPanel() {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        panel.setOpaque(false);

        JButton refreshButton = new JButton("새로 고침");
        refreshButton.addActionListener(event -> refresh());

        JButton decreaseButton = new JButton("수량 줄이기");
        decreaseButton.addActionListener(event -> decreaseSelected());

        JButton removeButton = new JButton("항목 삭제");
        removeButton.addActionListener(event -> removeSelected());

        JButton clearButton = new JButton("비우기");
        clearButton.addActionListener(event -> clearCart());

        panel.add(refreshButton);
        panel.add(decreaseButton);
        panel.add(removeButton);
        panel.add(clearButton);
        return panel;
    }

    private void refresh() {
        model.setRowCount(0);
        for (int i = 0; i < cart.getCartCount(); i++) {
            CartItem item = cart.getCartItem()[i];
            Book book = item.getItemBook();
            model.addRow(new Object[] {
                    item.getBookID(),
                    book.getName(),
                    item.getQuantity(),
                    book.getUnitPrice(),
                    item.getTotalPrice()
            });
        }
    }

    private int selectedCartIndex() {
        int row = table.getSelectedRow();
        if (row < 0) {
            JOptionPane.showMessageDialog(this, "항목을 선택하세요.");
            return -1;
        }

        String bookId = String.valueOf(model.getValueAt(table.convertRowIndexToModel(row), 0));
        return cart.findCartItemIndex(bookId);
    }

    private void decreaseSelected() {
        int index = selectedCartIndex();
        if (index < 0) {
            return;
        }

        CartItem item = cart.getCartItem()[index];
        if (item.getQuantity() > 1) {
            item.setQuantity(item.getQuantity() - 1);
        } else {
            cart.removeCart(index);
        }
        refresh();
    }

    private void removeSelected() {
        int index = selectedCartIndex();
        if (index < 0) {
            return;
        }

        int result = JOptionPane.showConfirmDialog(this, "선택한 항목을 삭제하겠습니까?", "항목 삭제",
                JOptionPane.YES_NO_OPTION);
        if (result == JOptionPane.YES_OPTION) {
            cart.removeCart(index);
            refresh();
        }
    }

    private void clearCart() {
        if (cart.getCartCount() == 0) {
            JOptionPane.showMessageDialog(this, "장바구니에 항목이 없습니다.");
            return;
        }

        int result = JOptionPane.showConfirmDialog(this, "장바구니를 비우겠습니까?", "장바구니 비우기",
                JOptionPane.YES_NO_OPTION);
        if (result == JOptionPane.YES_OPTION) {
            cart.deleteBook();
            refresh();
        }
    }
}
