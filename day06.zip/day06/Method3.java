package day06;
import java.util.Scanner;
public class Method3 {
//2개의 정수와 1개의 문자열을 입력 받아서 4칙연산을 수행하는 계산기 메소드 add, sub, mul, div 정의
//문자열이 + 이면 add호출, -이면 sub호출, *이면 mul호출, /이면 div호출
	public static int add(int a, int b) {
		return a+b;
	}
	public static int sub(int a, int b) {
		return a-b;
	}
	public static int mul(int a, int b) {
		return a*b;
	}
	public static int div(int a, int b) {
		return a/b;
	}
	
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		int result = 0;
		System.out.print("첫번째 값 입력 : ");
		int num1 = scan.nextInt();
		System.out.print("두번째 값 입력 : ");
		int num2 = scan.nextInt();
		System.out.print("연산 부호 입력 : ");
		String s = scan.next();
		if(s.equals("+")) {
			result = add(num1, num2);
		}
		else if(s.equals("-")) {
			result = sub(num1, num2);
		}
		else if(s.equals("*")) {
			result = mul(num1, num2);
		}
		else if(s.equals("/")) {
			result = div(num1, num2);
		}
		System.out.printf("%d %s %d = %d", num1, s, num2, result);
		
	}

}
