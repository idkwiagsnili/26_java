package day06;
import java.util.Scanner;
public class Method2 {

	public static int max(int a, int b) {
		int maximum = a;
		if(b > a) {
			return b;
		}
		return maximum;
	}
	
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		int num1 = scan.nextInt();
		int num2 = scan.nextInt();
		System.out.println("최대값 : " + max(num1, num2));;
		
	}

}
