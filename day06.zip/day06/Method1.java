package day06;
import java.util.Scanner;
public class Method1 {

	//1. 매개변수도 없고, 반환형도 없는 add()매소드
	public static void add() {
		Scanner scan = new Scanner(System.in);
		int num = scan.nextInt();
		int num2 = scan.nextInt();
		System.out.println(num + num2);
	}
	
	public static void add(int a, int b) {
		System.out.println(a + b);
	}
	
	public static int add1() {
		Scanner scan = new Scanner(System.in);
		int num = scan.nextInt();
		int num2 = scan.nextInt();
		return num + num2;
	}
	
	public static int add2(int a, int b) {
		return a+b;
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//add();
		//add(50, 60);
		//System.out.println(add1());
		int result = add2(50, 60);
		System.out.println(result);
	}

}
