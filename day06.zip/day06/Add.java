package day06;
import java.util.Scanner;
public class Add {

	public static void main(String[] args) {
		// 2개의 실수를 입력 받아서 곱한 결과를 출력하시오
		Scanner scan = new Scanner(System.in);
		float floatNum[];
		float total = 0;
		floatNum = new float[2];
		System.out.print("1번째값 입력 : ");
		floatNum[0] = scan.nextFloat();
		System.out.print("1번째값 입력 : ");
		floatNum[1] = scan.nextFloat();
		total = floatNum[0] * floatNum[1];
		System.out.println("총합 : " + total);
	}

}
