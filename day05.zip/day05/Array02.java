package day05;

import java.util.Scanner;

public class Array02 {

	public static void main(String[] args) {
		int intArray[];
		intArray = new int[5];
		int intSum = 0;
		Scanner scan = new Scanner(System.in);
		for(int i = 0;i < 5;i++) {
			System.out.print(i + 1 + "번째값 입력 : ");
			intArray[i] = scan.nextInt();
			intSum += intArray[i];
		}
		System.out.println("더한값값 : " + intSum);
		System.out.print("평균값 : " + (double)intSum/intArray.length);
	}

}
