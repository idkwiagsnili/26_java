package day05;
import java.util.Scanner;
public class Array01 {

	public static void main(String[] args) {
		int intArray[];
		intArray = new int[5];
		int intMax = intArray[0];
		Scanner scan = new Scanner(System.in);
		for(int i = 0;i < 5;i++) {
			System.out.print(i + 1 + "번째값 입력 : ");
			intArray[i] = scan.nextInt();
			if(intArray[i] > intMax) {
				intMax = intArray[i];
			}
		}
		System.out.print("최대값 : " + intMax);
	}

}