package day11;

public class SmartPhone extends Calc implements PhoneInterface{
	
	

	public static void main(String[] args) {
		SmartPhone sp = new SmartPhone();
		sp.sendCall();
		sp.receiveCall();
		System.out.println("3 + 5 = " + sp.calculate(3, 5));
		System.out.println(sp.toString());
	}

	@Override
	public void sendCall() {
		System.out.println("스마트폰 알람");
	}

	@Override
	public void receiveCall() {
		System.out.println("스마트폰 전화 옴");
	}
	
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "스마트폰임";
	}

}
